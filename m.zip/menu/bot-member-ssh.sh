#!/bin/bash
# //====================================================
# //	System Request:Debian 9+/Ubuntu 18.04+/20+
# //	Develovers >   LT
# //	email > scvip293@gmail.com
# //    telegram > https://t.me/LunaticTunnel
# //    whatsapp > 082240074362
# //====================================================
# // LUNATIC TUNNELING
NC='\e[0m'
red='\e[1;31m'
green='\e[0;32m'
yellow='\033[0;33m'
NMS="LOCKED"
NMM="UNLOCKED"
MYIP=$(wget -qO- ipinfo.io/ip)
echo -e "━━━━━━━━━━━━━━━━━━━━━━━━━"
echo -e "⭐ SHOW SSH OVPN ACCOUNT ⭐"
echo -e "━━━━━━━━━━━━━━━━━━━━━━━━━"
while read expired; do
    AKUN="$(echo $expired | cut -d: -f1)"
    ID="$(echo $expired | grep -v nobody | cut -d: -f3)"
    exp="$(chage -l $AKUN | grep "Account expires" | awk -F": " '{print $2}')"
    status="$(passwd -S $AKUN | awk '{print $2}')"
    if [[ $ID -ge 1000 ]]; then
        if [[ "$status" = "L" ]]; then
            echo -e " Account   : $AKUN"
            echo -e " Expired   : $exp"
            echo -e " Status    : $NMS"
            echo -e "━━━━━━━━━━━━━━━━━━━━━━━━━"
        else
            echo -e " Account   : $AKUN"
            echo -e " Expired   : $exp"
            echo -e " Status    : $NMM"
            echo -e "━━━━━━━━━━━━━━━━━━━━━━━━━"
        fi
    fi
done </etc/passwd
JUMLAH="$(awk -F: '$3 >= 1000 && $1 != "nobody" {print $1}' /etc/passwd | wc -l)"
echo -e "Account number: $JUMLAH user"
echo -e "━━━━━━━━━━━━━━━━━━━━━━━━━"

